const express = require("express");
const router = express.Router({ mergeParams: true });
const wrapAsync = require("../utils/wrapAsync.js");
const ExpressError = require("../utils/ExpressError.js");
const { listingSchema, reviewSchema } = require("../schema.js");
const Review = require("../models/review.js");
const Listing = require("../models/Listing.js");



// ================= CREATE REVIEW =================

router.post("/", wrapAsync(async (req, res) => {
console.log(req.params);
    let result = reviewSchema.validate(req.body);

    if (result.error) {
        throw new ExpressError(400, result.error);
    }

    let { id } = req.params;

    let listing = await Listing.findById(id);
    console.log("ID =", id);
console.log("Listing =", listing);

    let newReview = new Review(req.body.review);

    listing.reviews.push(newReview);

    await newReview.save();
    await listing.save();
     req.flash("success", "New Review Created!");

    res.redirect(`/listings/${id}`);

}));

// ================= DELETE REVIEW =================

router.delete("/:reviewId", wrapAsync(async (req, res) => {

    let { id, reviewId } = req.params;

    await Listing.findByIdAndUpdate(id, {
        $pull: { reviews: reviewId }
    });

    await Review.findByIdAndDelete(reviewId);
     req.flash("success", "Review Deleted!");

    res.redirect(`/listings/${id}`);

}));

module.exports = router;