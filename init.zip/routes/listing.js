const express = require("express");
// const router = express.Router();
const router = express.Router({ mergeParams: true });
const wrapAsync = require("../utils/wrapAsync.js");
const ExpressError = require("../utils/ExpressError.js");
const { listingSchema, reviewSchema } = require("../schema.js");
const Listing = require("../models/Listing.js");
const { isLoggedIn } = require("../middleware.js");


// ================= INDEX =================

router.get("/", wrapAsync(async (req, res) => {

    const allListing = await Listing.find({});

    res.render("listings/index.ejs", { allListing });

}));

// ================= NEW =================



router.get("/new", isLoggedIn, (req, res) => {
    res.render("listings/new");
});

// ================= SHOW =================

router.get("/:id", wrapAsync(async (req, res) => {

    let { id } = req.params;

    const listing = await Listing.findById(id)
        .populate("reviews")
        .populate("owner");

    console.log("OWNER =", listing.owner);    
    console.log(listing.owner);  

    res.render("listings/show.ejs", { listing });
}));

// ================= CREATE =================

router.post("/", isLoggedIn, wrapAsync(async (req, res) => {

    console.log("USER =", req.user);

    let result = listingSchema.validate(req.body);

    if (result.error) {
        throw new ExpressError(400, result.error);
    }

    const newListing = new Listing(req.body.listing);

    console.log("USER ID =", req.user._id);

    newListing.owner = req.user._id;

    await newListing.save();

    req.flash("success", "New Listing Created!");
    res.redirect("/listings");
}));

// ================= EDIT =================

router.get("/:id/edit",isLoggedIn, wrapAsync(async (req, res) => {

    let { id } = req.params;

    const listing = await Listing.findById(id);
    if(!listing){
      req.flash("error", "Listing you requested for does not exist!");
      res.redirect("/listings")
    
}

    res.render("listings/edit.ejs", { listing });

}));

// ================= UPDATE =================

router.put("/:id", isLoggedIn, wrapAsync(async (req, res) => {

    let { id } = req.params;

    await Listing.findByIdAndUpdate(id, {
        ...req.body.listing
    });
 req.flash("success", "Listing Updated!");
    res.redirect(`/listings/${id}`);

}));

// ================= DELETE LISTING =================

router.delete("/:id",isLoggedIn, wrapAsync(async (req, res) => {

    let { id } = req.params;
    let deleteListings = await Listing.findByIdAndDelete(id);
    console.log(deleteListings);
     req.flash("success", "Listing Deleted!");
    res.redirect("/listings");

}));

module.exports = router;