const mongoose = require("mongoose");
const initData = require("./data.js");
const Listing = require("../models/Listing");

const MONGO_URL = "mongodb://127.0.0.1:27017/StayBee";
main()
.then(() =>{
    console.log("connected to DB");
})
.catch((err) => {
    console.log(err);
});
async function main() {
    await mongoose.connect(MONGO_URL)
    
}
const data = initData.data.map((obj) => ({
    ...obj,
    owner: "YOUR_USER_OBJECT_ID",
}));

await Listing.deleteMany({});
await Listing.insertMany(data);
// const initDB = async () => {
   // await Listing.deleteMany({});
   // initData.data.map((obj) => ({...obj, owner:"6a50d616d814f313b3e48851"
    //}));
    //await Listing.insertMany(initData.data);
    //console.log("data was initialized");
// };

initDB();